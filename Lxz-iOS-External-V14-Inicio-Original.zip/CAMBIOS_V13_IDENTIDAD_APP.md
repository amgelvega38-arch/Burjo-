# EXTERNAL V1 V13 — identidad de la app

- El nombre en Ajustes se obtiene de `CFBundleDisplayName` / `CFBundleName` del bundle instalado.
- El icono en Ajustes se obtiene de LaunchServices para el bundle ID instalado (`iconForBundleID`), con fallback al icono integrado.
- El nombre por defecto de la app es `EXTERNAL V1`.
- El icono por defecto de compilación se cambió de la calculadora al icono Sonic incluido en el proyecto.
- Se conserva `PRODUCT_NAME = 3105` para no alterar el scheme/ejecutable del proyecto.
- Si una herramienta de firma modifica `Info.plist` y `AppIcon` del IPA, el nombre y el icono mostrados en Ajustes reflejarán esos valores instalados al abrir la pantalla.
